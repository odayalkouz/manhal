
/**
 * Created by osaid zalloum on 13/12/2020.
 */

var shuffleList1=[];
var shuffleList2=[];
var allList=[];

function drawItem(){
    shuffleList1=[];
    shuffleList2=[];
    allList=[];
    allList=Array.from(itemList);
    for(var i=0;i<worngList.length;i++){
        allList.push(worngList[i]);
    }
    var html="";
    var htmlDrop="";
    var htmlDrop2="";
    $(".header-container span").html(title);
    $(".drag-container").html("");
    $(".drop-container").html()
    $(".mark").fadeIn();
    shuffleList1=randomarray(allList.length);
    for(var i=0;i<allList.length;i++){
        shuffleList2.push(allList[shuffleList1[i]])
    }
    for(var i=0;i<shuffleList2.length;i++){
        if(shuffleList2[i].type==0){
            html+='<div class="drag-item" data="'+shuffleList2[i].type+'" row="'+shuffleList2[i].row+'"><a class="jq_removewanswer"></a><div class="inner-drag-item"><span>'+shuffleList2[i].text+'</span></div></div>'
        }else{
            html+='<div class="drag-item" data="'+shuffleList2[i].type+'" row="'+shuffleList2[i].row+'"><div class="inner-drag-item"><span>'+shuffleList2[i].text+'</span></div></div>'
        }
    }
    html+='<a class="jq_add_wanswer"></a>';
    $(".drag-container").append(html)
    $(".drag-item[data='0'] span").attr("contenteditable",'true');
    // shuffleDivs(".drag-container");

    // console.log("sssssssss<<<>>>"+$(".drop-container").length);
    // if(cloumns.length==1){
    //     $(".title-table-container").css("width","96.852%");
    //     $(".title-table-1 span").html(cloumns[0].title);
    //     $(".drop-main-container").css({'width':'39.3%','height':'57.813%'});
    //     $(".drop-container-1").css({'width':'91.612%','height':'81.137%','margin-right':'4.298%','margin-left':'0'});
    //     $(".title-table-1").css({'width':'98.22%','margin-left':'0'});
    //     for(var i=0;i<5;i++){
    //         htmlDrop+='<div class="drop-item drop-'+(i+1)+'"><a class="jq_remove_row" data-row="'+(i+1)+'"></a><div class="mark"></div><span></span></div>';
    //     }
    //     $(".drop-container-1").html(htmlDrop);
    //     $(".drop-item").css({'height':'18.77%','margin-bottom':'1.4%'})
    // }else if(cloumns.length==2){
    //     $(".title-table-1 span").html(cloumns[0].title);
    //     $(".title-table-2 span").html(cloumns[1].title);
    //     $(".drop-main-container").css({'width':'75.684%','height':'57.813%'});
    //     $(".drop-container-1").css({'width':'47.342%','height':'81.137%','margin-right':'1.298%','margin-left':'2.984%'});
    //     $(".drop-container-2").css({'width':'47.342%','height':'81.137%'});
    //     $(".title-table-1").css({'width':'49.478%','margin-left':'1%'});
    //     $(".title-table-2").css({'width':'49.478%','margin-left':'0'});
    //     for(var i=0;i<5;i++){
    //         htmlDrop+='<div class="drop-item drop-'+(i+1)+'"><div class="mark"></div><span></span></div>';
    //         htmlDrop2+='<div class="drop-item drop-'+(i+1)+'"><a class="jq_remove_row" data-row="'+(i+1)+'"></a><div class="mark"></div><span></span></div>';
    //     }
    //     $(".drop-container-1").html(htmlDrop2);
    //     $(".drop-container-2").html(htmlDrop);
    //     $(".drop-item").css({'height':'18.77%','margin-bottom':'1.4%'})
    // }else if(cloumns.length==3){
    //     $(".title-table-container").css({'height':'15.951%','margin-top':'0.8%'});
    //     $(".title-table-1 span").html(cloumns[0].title);
    //     $(".title-table-2 span").html(cloumns[1].title);
    //     $(".title-table-3 span").html(cloumns[2].title);
    //     // $(".drop-main-container").css('height','49.5%');
    //     $(".drop-main-container").css({'width':'96.7%','height':'46.3%'});
    //     $(".drop-container-1").css({'width':'31.13%','min-height':'68.464%','height':'77.437%','margin-right':'1.298%','margin-left':'2.084%','margin-top':'0.857%'});
    //     $(".drop-container-2").css({'width':'31.13%','min-height':'68.464%','height':'77.437%','margin-left':'2.084%','margin-top':'0.857%'});
    //     $(".drop-container-3").css({'width':'31.13%','min-height':'68.464%','height':'77.437%','margin-left':'0','margin-top':'0.857%'});
    //     $(".title-table-1").css({'width':'32.66%','margin-left':'1%'});
    //     $(".title-table-2").css({'width':'32.66%','margin-left':'1%'});
    //     $(".title-table-3").css({'width':'32.66%','margin-left':'0'});
    //     for(var i=0;i<4;i++){
    //         htmlDrop+='<div class="drop-item drop-'+(i+1)+'"><div class="mark"></div><span></span></div>';
    //         htmlDrop2+='<div class="drop-item drop-'+(i+1)+'"><a class="jq_remove_row" data-row="'+(i+1)+'"></a><div class="mark"></div><span></span></div>';
    //     }
    //     $(".drop-container-1").html(htmlDrop2);
    //     $(".drop-container-2").html(htmlDrop);
    //     $(".drop-container-3").html(htmlDrop);
    //     $(".drop-item").css({'height':'22.774%','margin-bottom':'2.7%'});
    //     $(".drag-container").css({'height':'35.28%','bottom':'3.205%'});
    //     $(".drag-item").css({'height':'30.64%','margin-right':'0.9%'});
    //     $('.drag-item:nth-child(5)').css({'margin-right':'0'});
    //     $('.drag-item:nth-child(6)').css({'margin-bottom':'1%'});
    //     $('.drag-item:nth-child(7)').css({'margin-bottom':'1%'});
    //     $('.drag-item:nth-child(8)').css({'margin-bottom':'1%'});
    //     $('.drag-item:nth-child(9)').css({'margin-bottom':'1%'});
    //     $('.drag-item:nth-child(10)').css({'margin-bottom':'1%','margin-right':'0'});
    //     $('.drag-item:nth-child(11)').css({'margin-right':'0.9%','margin-bottom':'0'});
    //     $('.drag-item:nth-child(12)').css({'margin-right':'0.9%','margin-bottom':'0'});
    //     $('.drag-item:nth-child(13)').css({'margin-right':'0.9%','margin-bottom':'0'});
    //     $('.drag-item:nth-child(14)').css({'margin-right':'0.9%','margin-bottom':'0'});
    //     $('.drag-item:nth-child(15)').css({'margin-right':'0.9%','margin-bottom':'0'});
    //     $('.drag-item:last-child').css({'margin-right':'0','margin-bottom':'0'});
    // }else if(cloumns.length==4){
    //     $(".title-table-container").css({'height':'19.941%','margin-top':'1.1%'});
    //     $(".title-table-1 span").html(cloumns[0].title);
    //     $(".title-table-2 span").html(cloumns[1].title);
    //     $(".title-table-3 span").html(cloumns[2].title);
    //     $(".title-table-4 span").html(cloumns[3].title);
    //     $(".drop-main-container").css({'width':'96.7%','height':'39.7%'});
    //     $(".drop-container-1").css({'width':'24.2%','min-height':'68.464%','margin-right':'0.798%','margin-left':'0.6%','margin-top':'1.257%'});
    //     $(".drop-container-2").css({'width':'24.2%','min-height':'68.464%','margin-left':'0.6%','margin-top':'1.257%'});
    //     $(".drop-container-3").css({'width':'24.2%','min-height':'68.464%','margin-left':'0.6%','margin-top':'1.257%'});
    //     $(".drop-container-4").css({'width':'24.2%','min-height':'68.464%','margin-left':'0','margin-top':'1.257%'});
    //     $(".title-table-1").css({'width':'24.2%','margin-left':'1%'});
    //     $(".title-table-2").css({'width':'24.2%','margin-left':'1%'});
    //     $(".title-table-3").css({'width':'24.2%','margin-left':'1%'});
    //     $(".title-table-4").css({'width':'24.2%','margin-left':'0'});
    //     for(var i=0;i<3;i++){
    //         htmlDrop+='<div class="drop-item drop-'+(i+1)+'"><div class="mark"></div><span></span></div>';
    //         htmlDrop2+='<div class="drop-item drop-'+(i+1)+'"><a class="jq_remove_row" data-row="'+(i+1)+'"></a><div class="mark"></div><span></span></div>';
    //     }
    //     $(".drop-container-1").html(htmlDrop2);
    //     $(".drop-container-2").html(htmlDrop);
    //     $(".drop-container-3").html(htmlDrop);
    //     $(".drop-container-4").html(htmlDrop);
    //     $(".drop-item").css({'height':'27%','margin-bottom':'2.7%'});
    //     $(".drag-container").css({'height':'35.28%','bottom':'6.205%'});
    //     $(".drag-item").css({'height':'30.64%'});
    //     $('.drag-item:nth-child(5)').css({'margin-right':'0'});
    //     $('.drag-item:nth-child(6)').css({'margin-bottom':'1%'});
    //     $('.drag-item:nth-child(7)').css({'margin-bottom':'1%'});
    //     $('.drag-item:nth-child(8)').css({'margin-bottom':'1%'});
    //     $('.drag-item:nth-child(9)').css({'margin-bottom':'1%'});
    //     $('.drag-item:nth-child(10)').css({'margin-bottom':'1%','margin-right':'0'});
    //     $('.drag-item:nth-child(11)').css({'margin-right':'0.9%','margin-bottom':'0'});
    //     $('.drag-item:nth-child(12)').css({'margin-right':'0.9%','margin-bottom':'0'});
    //     $('.drag-item:nth-child(13)').css({'margin-right':'0.9%','margin-bottom':'0'});
    //     $('.drag-item:nth-child(14)').css({'margin-right':'0.9%','margin-bottom':'0'});
    //     $('.drag-item:nth-child(15)').css({'margin-right':'0.9%','margin-bottom':'0'});
    //     $('.drag-item:last-child').css({'margin-right':'0','margin-bottom':'0'});
    // }


    // $(".title-table-container").css({'height':'19.941%','margin-top':'1.1%'});
    for(i=0;i<cloumns.length;i++){
        $(".title-table-"+(i+1).toString()+" span").html(cloumns[i].title);
    }
    // $(".title-table-1 span").html(cloumns[0].title);
    // $(".title-table-2 span").html(cloumns[1].title);
    // $(".title-table-3 span").html(cloumns[2].title);
    // $(".title-table-4 span").html(cloumns[3].title);

    // $(".drop-main-container").css({'width':'96.7%','height':'39.7%'});
    // $(".drop-container-1").css({'width':'24.2%','min-height':'68.464%','margin-right':'0.798%','margin-left':'0.6%','margin-top':'1.257%'});
    // $(".drop-container-2").css({'width':'24.2%','min-height':'68.464%','margin-left':'0.6%','margin-top':'1.257%'});
    // $(".drop-container-3").css({'width':'24.2%','min-height':'68.464%','margin-left':'0.6%','margin-top':'1.257%'});
    // $(".drop-container-4").css({'width':'24.2%','min-height':'68.464%','margin-left':'0','margin-top':'1.257%'});
    // $(".title-table-1").css({'width':'24.2%','margin-left':'1%'});
    // $(".title-table-2").css({'width':'24.2%','margin-left':'1%'});
    // $(".title-table-3").css({'width':'24.2%','margin-left':'1%'});
    // $(".title-table-4").css({'width':'24.2%','margin-left':'0'});
    // for(var i=0;i<3;i++){
    //     htmlDrop+='<div class="drop-item drop-'+(i+1)+'"><div class="mark"></div><span></span></div>';
    //     htmlDrop2+='<div class="drop-item drop-'+(i+1)+'"><a class="jq_remove_row" data-row="'+(i+1)+'"></a><div class="mark"></div><span></span></div>';
    // }

    // {text:'الصِّدْقُ',type:'1',row:1},
    // {text:'الأَمانَةُ',type:'1',row:2},
    console.log('itemList',itemList);
    for( i=0;i<itemList.length;i++){
        console.log('add',i);
        if(itemList[i].type=='1'){
            htmlDrop='<div class="drop-item drop-'+($(".drop-container-"+itemList[i].type+" .drop-item").length+1)+'"><a class="jq_remove_row" data-row="'+($(".drop-container-"+itemList[i].type+" .drop-item").length+1)+'"></a><div class="mark"></div><span contenteditable="true"  class="jq_cell">'+itemList[i].text+'</span></div>';
        }else{
            htmlDrop='<div class="drop-item drop-'+($(".drop-container-"+itemList[i].type+" .drop-item").length+1)+'"><div class="mark"></div><span contenteditable="true" class="jq_cell">'+itemList[i].text+'</span></div>';
        }
        console.log('cell',itemList[i].text);
        $(".drop-container-"+itemList[i].type).append(htmlDrop);
    }

    $(".drag-container").css({'height':'35.28%','bottom':'6.205%'});
    $(".drag-item").css({'height':'30.64%'});
    $('.drag-item:nth-child(5)').css({'margin-right':'0'});
    $('.drag-item:nth-child(10)').css({'margin-right':'0'});
    $('.drag-item:nth-child(11)').css({'margin-right':'0.9%'});
    $('.drag-item:nth-child(12)').css({'margin-right':'0.9%'});
    $('.drag-item:nth-child(13)').css({'margin-right':'0.9%'});
    $('.drag-item:nth-child(14)').css({'margin-right':'0.9%'});
    $('.drag-item:nth-child(15)').css({'margin-right':'0.9%'});
    $('.drag-item:last-child').css({'margin-right':'0'});

    setTimeout(function () {
        drag();

        $(".drop-item").droppable( "enable" );
        console.log('item length=',itemList.length);
    },200);

}
